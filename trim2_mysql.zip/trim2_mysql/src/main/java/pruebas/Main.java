package pruebas;

import javax.xml.transform.Result;
import java.sql.*;

public class Main {

    public static void main(String[] args) {

        //APERTURA DE CONEXIÓN
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/horarios_fp", "root", "root");

            DatabaseMetaData dbmd = connection.getMetaData();
            ResultSet result = null;

            //Obtención de meta datos
            String nombre = dbmd.getDatabaseProductName();
            String driver = dbmd.getDriverName();
            String url = dbmd.getURL();
            String usuario = dbmd.getUserName();

            //Mostramos meta datos
            System.out.printf("\nINFORMACIÓN SOBRE LA BASE DE DATOS:\n=========================" +
                    "\n· Nombre: %s\n· Driver: %s\n· URL: %s\n· Usuario: %s\n=========================\n",
                    nombre, driver, url, usuario);


            //Obtenemos información de las tablas y vistas
            result = dbmd.getTables("horarios_fp", "horarios_fp", "profesor", null);

            while(result.next()){
                String catalogo = result.getString(1);
                String esquema = result.getString(2);
                String tabla = result.getString(3);
                String tipo = result.getString(4);

                System.out.printf("\nINFORMACIÓN LAS TABLAS:\n=========================" +
                        "\n· Catalogo: %s\n· Esquema: %s\n· Tabla: %s\n· Tipo: %s\n=========================\n",
                        catalogo, esquema, tabla, tipo);
            }


            //OBTENEMOS INFORMACIÓN SOBRE LAS TABLAS
            System.out.printf("\nINFORMACIÓN SOBRE TABLA PROFESOR:\n=========================");
            ResultSet columnas = dbmd.getColumns("horarios_fp", "horarios_fp", "profesor", null);
            while (columnas.next()){
                String nombcol = columnas.getString("COLUMN_NAME");
                String tipoCol = columnas.getString("TYPE_NAME");
                String tamCol = columnas.getString("COLUMN_SIZE");
                String nula = columnas.getString("IS_NULLABLE");

                System.out.printf("\n· nColumna: %s · Tipo: %s · Tamaño: %s · ¿Puede ser nula?: %s",
                        nombcol, tipoCol, tamCol, nula);
            }
            System.out.printf("\n=========================\n");



            //CIERRE DE CONEXIÓN
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }



    }
}
